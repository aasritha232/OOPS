package pro.webnest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Random;
import pro.webnest.entity.User;
import pro.webnest.repository.UserRepository;

@Service
public class UserService {

	
	
	
    @Autowired
    private UserRepository userRepository;

    public User saveUser(User user) {
        return userRepository.save(user);
    }
    
    public User login(String email, String password) {
        return userRepository.findByEmailAndPassword(email, password);
    }
    
    
    
    //generate otp

    @Autowired
    private EmailService emailService;
    
    public String generateOTP() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }
    //send otp
    
    public void sendOtpToEmail(String email) {
        User user = userRepository.findByEmail(email);

        if (user == null) {
            throw new RuntimeException("User not found");
        }

        String otp = generateOTP();

        user.setOtp(otp);
        user.setOtpGeneratedTime(System.currentTimeMillis());

        userRepository.save(user);

        emailService.sendOTP(email, otp);
    }
    
    
    //verify otp
    public boolean verifyOtp(String email, String otp) {
        User user = userRepository.findByEmail(email);

        if (user == null) return false;

        if (user.getOtp().equals(otp)) {
            long currentTime = System.currentTimeMillis();
            long otpTime = user.getOtpGeneratedTime();

            if ((currentTime - otpTime) <= 300000) { // 5 minutes
                return true;
            }
        }
        return false;
    }
    
    //reset otp
    public void resetPassword(String email, String newPassword) {
        User user = userRepository.findByEmail(email);

        if (user == null) {
            throw new RuntimeException("User not found");
        }

        System.out.println("RESET EMAIL: " + email);
        System.out.println("NEW PASSWORD: " + newPassword);

        user.setPassword(newPassword);

        userRepository.save(user);
    }

}
